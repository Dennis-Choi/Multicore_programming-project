실행 방법
1. make
2. ./myshell

phase3
job구조체를 만들고 이러한 job의 정보를 저장하는 배열을 만들어 각 프로세스 별로 어떠한 상태인지를 기록한다.
상태로는 Background Running(BG) 상태, Foreground Running(FG) 상태, Background Stopped(Stop) 상태가 존재한다.
이러한 job 구조체를 만들고 관리하는 이유는 각 Signal 별로 프로세스의 상태가 달라지기 때문이며, 이러한 Signal의 역할에 부가적이 기능을 줄 수 있는
signal handler또한 3종류(sigint, sigchild, sigstop)을 만들어 주었다.
추가로 fg,bg,kill 명령어는 지정한 pid의 프로세스에 신호를 주기 때문에, pid에 맞는 job의 상태도 바꾸어주고, Kill함수를 이용해 
fg,bg의 경우에는 SIGCONT 신호를, kill의 경우에는 SIGKILL 신호를 해당 pid에 전달해준다.
