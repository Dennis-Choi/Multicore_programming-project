/* $begin shellmain */
#include "csapp.h"
#include <errno.h>
#define MAXARGS 128

/* Function */
void eval(char *cmdline, int N);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);
void do_cmd(char **argv, int bg);

int main()
{
	char cmdline[MAXLINE]; /* Command line */
	char *a;
	while (1)
	{
		/* Read */
		printf("CSE20191662 > ");
		a = fgets(cmdline, MAXLINE, stdin);
		if (feof(stdin))
			exit(0);

		/* Evaluate */
		if (cmdline[0] == '!') //!!는 기록 안함
			eval(cmdline, 0);
		else // 나머지는 기록함
			eval(cmdline, 1);
	}
}
/* $end shellmain */
void do_cmd(char **argv, int bg)
{
	pid_t pid;

	if (!builtin_command(argv)) // if not builtin_cmd
	{
		if ((pid = Fork()) == 0)
		{

			if (execvp(argv[0], argv) < 0)
			{
				printf("%s: Command not found.\n", argv[0]);
				exit(0);
			}
		}
		/* Parent waits for foreground job to terminate */
		if (!bg)
		{
			int status;
			if (waitpid(pid, &status, 0) < 0)
			{
				unix_error("waitfg: waitpid error");
			}
		}
	}

	else // if builtin_cmd
	{
		FILE *rfp = fopen("/sogang/under/cse20191662/phase1/history.txt", "r");
		if (!strcmp(argv[0], "cd"))
			chdir(argv[1]);

		else if (!strcmp(argv[0], "history"))
		{
			if (rfp != NULL)
			{
				char str[MAXLINE];
				int c = 1;
				while (fgets(str, MAXLINE, rfp) != NULL)
				{
					printf("%d   %s", c++, str);
				}
				fclose(rfp);
			}
		}
		else if (!strcmp(argv[0], "!!"))
		{
			if (rfp != NULL)
			{
				char str[MAXLINE];
				while (!feof(rfp))
				{
					if (fgets(str, MAXLINE, rfp) == NULL)
					{
						break;
					}
				}
				printf("%s", str);
				fclose(rfp);
				eval(str, 0);
			}
		}
		else if (argv[0][0] == '!')
		{
			if (rfp != NULL)
			{
				char str[MAXLINE];
				int c = 1;
				while (fgets(str, MAXLINE, rfp) != NULL)
				{
					if (c == argv[0][1] - '0')
					{
						printf("%s", str);
						fclose(rfp);
						eval(str, 1);
						break;
					}
					c++;
				}
			}
		}
	}
}

/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline, int N)
{
	char *argv[MAXARGS]; /* Argument list execve() */
	char buf[MAXLINE];	 /* Holds modified command line */
	int bg;				 /* Should the job run in bg or fg? */
	pid_t pid;			 /* Process id */

	char newcmdline[MAXLINE];
	int i = 0, j = 0;
	while (cmdline[i] != '\0')
	{
		if (cmdline[i] == '\"')
		{
			i++;
		}
		else
		{
			if(cmdline[i]=='|' || cmdline[i]=='&') {
				newcmdline[j++]=' ';
				newcmdline[j++] = cmdline[i];
				newcmdline[j] = ' ';
			}
			else{
				newcmdline[j] = cmdline[i];
			}	
			i++;
			j++;
		}
	}

	newcmdline[j] = '\0';

	strcpy(buf, newcmdline);
	bg = parseline(buf, argv);

	if (argv[0] == NULL)
		return; /* Ignore empty lines */

	FILE *rfp = fopen("/sogang/under/cse20191662/phase1/history.txt", "r");

	char str[MAXLINE] = "";
	if (rfp != NULL)
	{
		while (!feof(rfp))
		{
			fgets(str, MAXLINE, rfp);
		}
		fclose(rfp);
	}

	FILE *fp = fopen("/sogang/under/cse20191662/phase1/history.txt", "a");
	if (N == 1 && fp != NULL && strcmp(str, cmdline) != 0)
	{
		fprintf(fp, "%s", cmdline);
		fclose(fp);
	}
	else
	{
		fclose(fp);
	}

	do_cmd(argv, bg);

	return;
}
/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv)
{
	if (!strcmp(argv[0], "exit")) /* exit command */
		exit(0);
	if (!strcmp(argv[0], "&")) /* Ignore singleton & */
		return 1;
	if (!strcmp(argv[0], "cd") || !strcmp(argv[0], "history") || argv[0][0] == '!')
		return 1;
	return 0; /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv)
{
	char *delim; /* Points to first space delimiter */
	int argc;	 /* Number of args */
	int bg;		 /* Background job? */

	buf[strlen(buf) - 1] = ' ';	  /* Replace trailing '\n' with space */
	while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

	/* Build the argv list */
	argc = 0;
	while ((delim = strchr(buf, ' ')))
	{
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
			buf++;
	}
	argv[argc] = NULL;

	if (argc == 0) /* Ignore blank line */
		return 1;

	/* Should the job run in the background? */
	if ((bg = (*argv[argc - 1] == '&')) != 0)
		argv[--argc] = NULL;

	return bg;
}
/* $end parseline */
