#include "csapp.h"
typedef struct _TreeNode
{
    int id;
    int left_stock;
    int price;
    struct _TreeNode *left;
    struct _TreeNode *right;
} TreeNode;

typedef struct
{
    int maxfd;
    fd_set read_set;
    fd_set ready_set;
    int nready;
    int maxi;
    int clientfd[FD_SETSIZE];
    rio_t clientrio[FD_SETSIZE];
} pool;

void echo(int connfd);
void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p);
void check_clients(pool *p, TreeNode *root);
void do_update_stock_table(char *str, int fd, pool *p, int i, TreeNode *root, char *msg);

TreeNode *insert(TreeNode *root, int id, int left_stock, int price);
void print_tree(TreeNode *root, char *shownode);
TreeNode *search(TreeNode *root, int id);

int byte_cnt = 0;
int start = 1;
int total = 0;
/************************************/
struct timeval startTime, endTime;
double diffTime;
/************************************/
int main(int argc, char **argv)
{
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    static pool pool;
    char client_hostname[MAXLINE], client_port[MAXLINE];
    int ID, LEFT_STOCK, PRICE;
    TreeNode *root = NULL;
    FILE *fp = fopen("stock.txt", "r");
    while (feof(fp) == 0)
    {
        fscanf(fp, "%d %d %d", &ID, &LEFT_STOCK, &PRICE);
        root = insert(root, ID, LEFT_STOCK, PRICE);
    }
    fclose(fp);

    if (argc != 2)
    {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);
    while (1)
    {
        pool.ready_set = pool.read_set;
        pool.nready = Select(pool.maxfd + 1, &pool.ready_set, NULL, NULL, NULL);
        if (FD_ISSET(listenfd, &pool.ready_set))
        {
            clientlen = sizeof(struct sockaddr_storage);
            connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
            Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
            printf("Connected to (%s, %s)\n", client_hostname, client_port);
            add_client(connfd, &pool);
            total++;
            if (start)
            {
                gettimeofday(&startTime, NULL);
                start = 0;
            }
        }
        check_clients(&pool, root);
        if (total == 0)
        {
            gettimeofday(&endTime, NULL);
            diffTime = (endTime.tv_sec - startTime.tv_sec) + ((endTime.tv_usec - startTime.tv_usec) / 1000000);
            FILE *rp = fopen("analysis.txt", "a");
            fprintf(rp, "전체 처리수 %d의동시 처리율: %f\n", byte_cnt, (float)byte_cnt / diffTime);
            fclose(rp);
            byte_cnt = 0;
            start = 1;
        }
    }
}

void init_pool(int listenfd, pool *p)
{

    int i;
    p->maxi = -1;
    for (i = 0; i < FD_SETSIZE; i++)
        p->clientfd[i] = -1;

    p->maxfd = listenfd;
    FD_ZERO(&p->read_set);
    FD_SET(listenfd, &p->read_set);
}

void add_client(int connfd, pool *p)
{
    int i;
    p->nready--;
    for (i = 0; i < FD_SETSIZE; i++)
        if (p->clientfd[i] < 0)
        {

            p->clientfd[i] = connfd;
            Rio_readinitb(&p->clientrio[i], connfd);

            FD_SET(connfd, &p->read_set);

            if (connfd > p->maxfd)
                p->maxfd = connfd;
            if (i > p->maxi)
                p->maxi = i;
            break;
        }
    if (i == FD_SETSIZE)
        app_error("add_client error: Too many clients");
}

void check_clients(pool *p, TreeNode *root)
{
    int i, connfd, n;
    char buf[MAXLINE];
    rio_t rio;
    for (i = 0; (i <= p->maxi) && (p->nready > 0); i++)
    {
        connfd = p->clientfd[i];
        rio = p->clientrio[i];

        if ((connfd > 0) && (FD_ISSET(connfd, &p->ready_set)))
        {
            p->nready--;
            if ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0)
            {
                byte_cnt++;
                printf("Server received %d byte\n", n);
                char msg[MAXLINE];
                memset(msg, 0, sizeof(msg));
                strcpy(msg, buf);
                if (!strcmp(buf, "exit\n"))
                {
                    Rio_writen(connfd, msg, strlen(msg));
                    Close(connfd);
                    FD_CLR(connfd, &p->read_set);
                    p->clientfd[i] = -1;
                }
                else
                {
                    do_update_stock_table(buf, connfd, p, i, root, msg);
                    Rio_writen(connfd, msg, strlen(msg));
                }
            }

            else
            {
                Close(connfd);
                FD_CLR(connfd, &p->read_set);
                p->clientfd[i] = -1;
                total--;
            }
        }
    }
}

void do_update_stock_table(char *str, int fd, pool *p, int i, TreeNode *root, char *msg)
{
    char rest[MAXLINE];
    strcpy(rest, str);
    char *tmpstr = strtok(rest, " ");
    if (!strcmp(tmpstr, "show\n"))
    {
        print_tree(root, msg);
    }
    else if (!strcmp(tmpstr, "buy"))
    {
        TreeNode *ptr = NULL;
        char rest[MAXLINE];
        strcpy(rest, str);
        char *tmpstr;
        tmpstr = strtok(rest, " ");
        tmpstr = strtok(NULL, " ");
        ptr = search(root, atoi(tmpstr));
        tmpstr = strtok(NULL, " ");
        if (ptr == NULL)
        {
            return;
        }
        if (ptr->left_stock >= atoi(tmpstr) && atoi(tmpstr) != 0)
        {
            strcat(msg, "[buy] success\n");
            ptr->left_stock -= atoi(tmpstr);
            FILE *fp = fopen("stock.txt", "w");
            char shownode[MAXLINE] = "";
            print_tree(root, shownode);
            for (int i = 0; i < strlen(shownode) - 1; i++)
            {
                fprintf(fp, "%c", shownode[i]);
            }
            fclose(fp);
        }
        else
        {
            strcat(msg, "Not enough left stock\n");
        }
    }
    else if (!strcmp(tmpstr, "sell"))
    {
        TreeNode *ptr = NULL;
        char rest[MAXLINE];
        strcpy(rest, str);
        char *tmpstr;
        tmpstr = strtok(rest, " ");
        tmpstr = strtok(NULL, " ");
        ptr = search(root, atoi(tmpstr));
        tmpstr = strtok(NULL, " ");
        if (ptr == NULL)
        {
            return;
        }
        strcat(msg, "[sell] success\n");
        ptr->left_stock += atoi(tmpstr);
        FILE *fp = fopen("stock.txt", "w");
        char shownode[MAXLINE] = "";
        print_tree(root, shownode);
        for (int i = 0; i < strlen(shownode) - 1; i++)
        {
            fprintf(fp, "%c", shownode[i]);
        }
        fclose(fp);
    }
}

TreeNode *search(TreeNode *root, int id)
{
    if (root == NULL)
    {
        return root;
    }

    if (id == root->id)
    {
        return root;
    }
    else if (id < root->id)
    {
        search(root->left, id);
    }
    else if (id > root->id)
    {
        search(root->right, id);
    }
}

void print_tree(TreeNode *root, char *shownode)
{
    if (root == NULL)
    {
        return;
    }

    char ID[100000], LEFT_STOCK[100000], PRICE[100000];
    sprintf(ID, "%d", root->id);
    sprintf(LEFT_STOCK, "%d", root->left_stock);
    sprintf(PRICE, "%d", root->price);

    strcat(shownode, ID);
    strcat(shownode, " ");
    strcat(shownode, LEFT_STOCK);
    strcat(shownode, " ");
    strcat(shownode, PRICE);
    strcat(shownode, "\n");

    print_tree(root->left, shownode);
    print_tree(root->right, shownode);
}

TreeNode *insert(TreeNode *root, int id, int left_stock, int price)
{
    TreeNode *ptr;
    TreeNode *newNode = (TreeNode *)malloc(sizeof(TreeNode));
    newNode->id = id;
    newNode->left_stock = left_stock;
    newNode->price = price;
    newNode->left = newNode->right = NULL;

    if (root == NULL)
    {
        root = newNode;
        return root;
    }

    ptr = root;

    while (ptr)
    {
        if (id == ptr->id)
        {
            printf("Error : 중복값은 허용되지 않습니다!\n");
            return root;
        }
        else if (id < ptr->id)
        {
            if (ptr->left == NULL)
            {
                ptr->left = newNode;
                return root;
            }
            else
            {
                ptr = ptr->left;
            }
        }
        else
        {
            if (ptr->right == NULL)
            {
                ptr->right = newNode;
                return root;
            }
            else
            {
                ptr = ptr->right;
            }
        }
    }
}