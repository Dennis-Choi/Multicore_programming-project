
#include "csapp.h"
#define NTHREADS 100
#define SBUFSIZE 101

typedef struct{
    int *buf;
    int n;
    int front;
    int rear;
    sem_t mutex;
    sem_t slots;
    sem_t items;
} sbuf_t;

sbuf_t sbuf;
typedef struct _TreeNode
{
    int id;
    int left_stock;
    int price;
    struct _TreeNode *left;  
    struct _TreeNode *right;
} TreeNode;

TreeNode *root = NULL;
static int byte_cnt;
static sem_t mutex;
/************************************/
struct timeval startTime, endTime;
double diffTime = 0;
/************************************/
int total = 0;
int start = 1;

static void init_echo_cnt(void);
void echo_cnt(int connfd);
void do_update_stock_table(char *str, int fd, char *msg);
TreeNode *insert(TreeNode *root, int id, int left_stock, int price);
void print_tree(TreeNode *root, char *shownode);
TreeNode *search(TreeNode *root, int id);

void *thread(void *vargp);

void sbuf_init(sbuf_t *sp,int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp,int item);
int sbuf_remove(sbuf_t *sp);

int main(int argc, char **argv)
{
    int i, listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    pthread_t tid;

    char client_hostname[MAXLINE], client_port[MAXLINE];

    int ID, LEFT_STOCK, PRICE;
    FILE *fp = fopen("stock.txt", "r");
    while (feof(fp) == 0)
    {
        fscanf(fp, "%d %d %d", &ID, &LEFT_STOCK, &PRICE);
        root = insert(root, ID, LEFT_STOCK, PRICE);
    }
    fclose(fp);

    if (argc != 2)
    {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }
    listenfd = Open_listenfd(argv[1]);

    sbuf_init(&sbuf, SBUFSIZE);           
    for (i = 0; i < NTHREADS; i++) 
        Pthread_create(&tid, NULL, thread, NULL);            
    
    Sem_init(&mutex, 0, 1);
    while (1)
    {
        clientlen = sizeof(struct sockaddr_storage);
        connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
        sbuf_insert(&sbuf, connfd);
        Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
        printf("Connected to (%s, %s)\n", client_hostname, client_port);
        P(&mutex);
        total++;
        if(start){
             gettimeofday(&startTime, NULL);
             start=0;
        }
        V(&mutex);
    }
}


void *thread(void *vargp)
{
    Pthread_detach(pthread_self()); 
    while (1)
    {
        int connfd = sbuf_remove(&sbuf); 
        echo_cnt(connfd);                                          
        Close(connfd);
         P(&mutex);
        total--;
        if (total==0)
        {
            gettimeofday(&endTime, NULL);
            diffTime = (endTime.tv_sec - startTime.tv_sec) + ((endTime.tv_usec - startTime.tv_usec) / 1000000);
    
            FILE *rp = fopen("analysis.txt", "a");
            fprintf(rp, "전체 처리수 %d의 동시 처리율: %f\n", byte_cnt, (float)byte_cnt / diffTime);
            fclose(rp);
            byte_cnt=0;
            start = 1;
        }
        V(&mutex);
    }
}


static void init_echo_cnt(void)
{
    Sem_init(&mutex, 0, 1);
    byte_cnt = 0;
}

void echo_cnt(int connfd)
{
    int n;
    char buf[MAXLINE];
    rio_t rio;
    static pthread_once_t once = PTHREAD_ONCE_INIT;
    Pthread_once(&once, init_echo_cnt);
    Rio_readinitb(&rio, connfd);
    while ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0)
    {
        P(&mutex);
        byte_cnt++; 
        printf("Server received %d byte\n", n);
        V(&mutex);
        char msg[MAXLINE];
        memset(msg, 0, sizeof(msg));
        strcpy(msg, buf);
        if (!strcmp(buf, "exit\n"))
        {
            Rio_writen(connfd, msg, strlen(msg));
            return;
        }
        else
        {
            P(&mutex);
            do_update_stock_table(buf, connfd, msg);
            V(&mutex);
            Rio_writen(connfd, msg, strlen(msg));
        }
    }
}
void do_update_stock_table(char *str, int fd, char *msg)
{
    char rest[MAXLINE];
    strcpy(rest, str);
    char *tmpstr = strtok(rest, " ");
    if (!strcmp(tmpstr, "show\n"))
    {
        print_tree(root, msg);
    }
    else if (!strcmp(tmpstr, "buy"))
    {
        TreeNode *ptr = NULL;
        char rest[MAXLINE];
        strcpy(rest, str);
        char *tmpstr;
        tmpstr = strtok(rest, " ");
        tmpstr = strtok(NULL, " ");
        ptr = search(root, atoi(tmpstr));
        tmpstr = strtok(NULL, " ");
        if (ptr == NULL)
        {
            return;
        }
        if (ptr->left_stock >= atoi(tmpstr) && atoi(tmpstr) != 0)
        {
            strcat(msg, "[buy] success\n");
            ptr->left_stock -= atoi(tmpstr);
            FILE *fp = fopen("stock.txt", "w");
            char shownode[MAXLINE] = "";
            print_tree(root, shownode);
            for (int i = 0; i < strlen(shownode) - 1; i++)
            {
                fprintf(fp, "%c", shownode[i]);
            }
            fclose(fp);
        }
        else
        {
            strcat(msg, "Not enough left stock\n");
        }
    }
    else if (!strcmp(tmpstr, "sell"))
    {
        TreeNode *ptr = NULL;
        char rest[MAXLINE];
        strcpy(rest, str);
        char *tmpstr;
        tmpstr = strtok(rest, " ");
        tmpstr = strtok(NULL, " ");
        ptr = search(root, atoi(tmpstr));
        tmpstr = strtok(NULL, " ");
        if (ptr == NULL)
        {
            return;
        }
        strcat(msg, "[sell] success\n");
        ptr->left_stock += atoi(tmpstr);
        FILE *fp = fopen("stock.txt", "w");
        char shownode[MAXLINE] = "";
        print_tree(root, shownode);
        for (int i = 0; i < strlen(shownode) - 1; i++)
        {
            fprintf(fp, "%c", shownode[i]);
        }
        fclose(fp);
    }
}

TreeNode *search(TreeNode *root, int id)
{
    if (root == NULL)
    { 
        return root;
    }

    if (id == root->id)
    { 
        return root;
    }
    else if (id < root->id)
    { 
        search(root->left, id);
    }
    else if (id > root->id)
    { 
        search(root->right, id);
    }
}

void print_tree(TreeNode *root, char *shownode)
{
    if (root == NULL)
    {
        return;
    }

    char ID[100000], LEFT_STOCK[100000], PRICE[100000];
    sprintf(ID, "%d", root->id);
    sprintf(LEFT_STOCK, "%d", root->left_stock);
    sprintf(PRICE, "%d", root->price);

    strcat(shownode, ID);
    strcat(shownode, " ");
    strcat(shownode, LEFT_STOCK);
    strcat(shownode, " ");
    strcat(shownode, PRICE);
    strcat(shownode, "\n");

    print_tree(root->left, shownode);
    print_tree(root->right, shownode);
}

TreeNode *insert(TreeNode *root, int id, int left_stock, int price)
{
    TreeNode *ptr;                                        
    TreeNode *newNode = (TreeNode *)malloc(sizeof(TreeNode)); 
    newNode->id = id;
    newNode->left_stock = left_stock;
    newNode->price = price;
    newNode->left = newNode->right = NULL;

    if (root == NULL)
    { 
        root = newNode;
        return root;
    }

    ptr = root; 

    while (ptr)
    {
        if (id == ptr->id)
        { 
            printf("Error : 중복값은 허용되지 않습니다!\n");
            return root;
        }
        else if (id < ptr->id)
        { 
            if (ptr->left == NULL)
            { 
                ptr->left = newNode;
                return root;
            }
            else
            { 
                ptr = ptr->left;
            }
        }
        else
        { 
            if (ptr->right == NULL)
            { 
                ptr->right = newNode;
                return root;
            }
            else
            { 
                ptr = ptr->right;
            }
        }
    }
}

void sbuf_init(sbuf_t *sp,int n){
    sp->buf = Calloc(n,sizeof(int));
    sp->n = n;
    sp->front = sp->rear = 0;
    Sem_init(&sp->mutex, 0 ,1);
    Sem_init(&sp->slots,0,n);
    Sem_init(&sp->items, 0 ,0);
}
void sbuf_deinit(sbuf_t *sp){
    Free(sp->buf);
}
void sbuf_insert(sbuf_t *sp,int item){
    P(&sp->slots);
    P(&sp->mutex);
    sp->buf[(++sp->rear)%(sp->n)] = item;
    V(&sp->mutex);
    V(&sp->items);
}
int sbuf_remove(sbuf_t *sp){
    int item;
    P(&sp->items);
    P(&sp->mutex);
    item = sp->buf[(++sp->front)%(sp->n)];
    V(&sp->mutex);
    V(&sp->slots);
    return item;
}   